# RRCL anonymous TMLR supplement

This bundle contains four deterministic, manifest-bearing archives:

- retained development diagnostics (`core.zip`);
- the preregistered controlled synthetic boundary study (`synthetic.zip`);
- the frozen single-shot FDST boundary result (`fdst.zip`);
- the preregistered held-out learned-selector and matched-baseline study
  (`selector_v2.zip`).

Diagnostic Oracles use held-out labels only to measure opportunity and are not
deployable methods. FDST raw images, videos, and annotations are not
redistributed. The FDST archive contains only derived results, split metadata,
protocol records, and validation code. Identity fields and private local paths
are replaced by explicit anonymous or symbolic tokens for double-blind review.
The selector-v2 component uses disjoint synthetic tasks and does not reuse
FDST.
